package com.packt.animation.buggybubbles;

import com.packt.animation.bubbles.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Debug;

public class BuggyBubblesActivity extends Activity {
	/** Called when the activity is first created. */

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);


	}
}